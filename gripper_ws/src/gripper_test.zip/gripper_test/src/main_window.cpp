/**
 * @file /src/main_window.cpp
 *
 * @brief Implementation for the qt gui.
 *
 * @date February 2011
 **/
/*****************************************************************************
** Includes
*****************************************************************************/

// #include <QtGui>
#include "main_window.hpp"

/*****************************************************************************
** Namespaces
*****************************************************************************/

using namespace Qt;

/*****************************************************************************
** Implementation [MainWindow]
*****************************************************************************/

namespace gripper_ui {

MainWindow::MainWindow(int argc, char **argv, QWidget *parent): QMainWindow(parent) {
    ui.setupUi(this); // Calling this incidentally connects all ui's triggers to on_...() callbacks in this class.

    rclcpp::init(argc, argv);

    static shared_ptr<rclcpp::Node> node = rclcpp::Node::make_shared("grp");

    //setWindowIcon(QIcon(":/images/icon.png"));
    grp_node_ = new GripperNode(argc, argv, node);

    QObject::connect(grp_node_, SIGNAL(rosShutdown()), this, SLOT(close()));

    // Button mapping
    QObject::connect(ui.pushButton_cmd_enable    , SIGNAL(clicked()), this, SLOT(pushButton_cmdEnableCallback()));
    QObject::connect(ui.pushButton_cmd_disable   , SIGNAL(clicked()), this, SLOT(pushButton_cmdDisableCallback()));
    QObject::connect(ui.pushButton_cmd_power_on  , SIGNAL(clicked()), this, SLOT(pushButton_cmdPowerOnCallback()));
    QObject::connect(ui.pushButton_cmd_power_off , SIGNAL(clicked()), this, SLOT(pushButton_cmdPowerOffCallback()));
    QObject::connect(ui.pushButton_cmd_pos_ctrl  , SIGNAL(clicked()), this, SLOT(pushButton_cmdPosCtrlCallback()));
    QObject::connect(ui.pushButton_cmd_vel_ctrl  , SIGNAL(clicked()), this, SLOT(pushButton_cmdVelCtrlCallback()));
    QObject::connect(ui.pushButton_cmd_cur_ctrl  , SIGNAL(clicked()), this, SLOT(pushButton_cmdCurCtrlCallback()));
    QObject::connect(ui.pushButton_cmd_stop      , SIGNAL(clicked()), this, SLOT(pushButton_stopMotorCallback()));
    QObject::connect(ui.pushButton_set_param     , SIGNAL(clicked()), this, SLOT(pushButton_setMaxValueCallback()));
    QObject::connect(ui.pushButton_cmd_modbus_on , SIGNAL(clicked()), this, SLOT(pushButton_cmdModbusOnCallback()));
    QObject::connect(ui.pushButton_cmd_modbus_off, SIGNAL(clicked()), this, SLOT(pushButton_cmdModbusOffCallback()));
    QObject::connect(ui.pushButton_slave_change  , SIGNAL(clicked()), this, SLOT(pushButton_slaveChangeCallback()));

    QObject::connect(ui.pushButton_cmd_initial    , SIGNAL(clicked()), this, SLOT(pushButton_grpInitCallback()));
    QObject::connect(ui.pushButton_cmd_grp_open   , SIGNAL(clicked()), this, SLOT(pushButton_grpOpenCallback()));
    QObject::connect(ui.pushButton_cmd_grp_close  , SIGNAL(clicked()), this, SLOT(pushButton_grpCloseCallback()));
    QObject::connect(ui.pushButton_set_param_2    , SIGNAL(clicked()), this, SLOT(pushButton_setPIDCallback()));
    QObject::connect(ui.pushButton_cmd_grpPos_ctrl, SIGNAL(clicked()), this, SLOT(pushButton_grpPosCtrlCallback()));
    QObject::connect(ui.pushButton_cmd_initial2   , SIGNAL(clicked()), this, SLOT(pushButton_grpInit2Callback()));
    QObject::connect(ui.pushButton_cmd_grp_vacOn  , SIGNAL(clicked()), this, SLOT(pushButton_vacOnCallback()));
    QObject::connect(ui.pushButton_cmd_grp_vacOff , SIGNAL(clicked()), this, SLOT(pushButton_vacOffCallback()));

    // FIXME:
    argc = 5;
    argv[1] = "1"; // Driver #, 회전판: 2

    if (argc > 1) {
        string address_str = argv[1];
        uint slave_address = stoi(address_str);

        switch (slave_address) {
            case 1:
                ui.radioButton_slave_address_1->setChecked(true);
                break;
            case 2:
                ui.radioButton_slave_address_2->setChecked(true);
                break;
            case 3:
                ui.radioButton_slave_address_3->setChecked(true);
                break;
            default:
                cout << "---[ERROR] Slave address #" << slave_address << " is not reachable!---" << endl;
                break;
        }

        cout << "--------------------------------------" << endl;
        cout << "---[INFO] Slave address #" << slave_address << "------------" << endl;
        cout << "--------------------------------------" << endl;

        grp_node_->init(slave_address);

        timer_ = new QTimer(this);
        connect(timer_, SIGNAL(timeout()), this, SLOT(timerCallback()));
        timer_->start(200);   // msec

        // Initial value
        ui.lineEdit_monitor_pos->setText("0 deg");
        ui.lineEdit_monitor_cur->setText("0 mA");

        ui.spinBox_param_max_acc->setValue(30000);
        ui.spinBox_param_max_vel->setValue(18000);
    } else {
        cout << "--------------------------------------" << endl;
        cout << "---[ERROR] Slave address required !---" << endl;
        cout << "--------------------------------------" << endl;
    }
}

MainWindow::~MainWindow() {
    if(grp_node_ != NULL) {
        delete grp_node_;
    }

    if(timer_ != NULL) {
        delete timer_;
    }
}

void MainWindow::timerCallback() {
    // Display
    ui.lineEdit_monitor_pos    -> setText(QString::number(grp_node_->msg_.angle  , 'd', 0) + " deg");
    ui.lineEdit_monitor_cur    -> setText(QString::number(grp_node_->msg_.current, 'd', 0) + " mA");
    ui.lineEdit_monitor_vel    -> setText(QString::number(grp_node_->msg_.velocity, 'd', 0) + " RPM");
    ui.lineEdit_monitor_status -> setText(QString::fromStdString(grp_node_->MB_STATUS));
    ui.lineEdit_monitor_grpdir -> setText(QString::fromStdString(grp_node_->MB_GRP_DIR));
}

void MainWindow::pushButton_cmdEnableCallback() {
    grp_node_->driverEnable();
}

void MainWindow::pushButton_cmdDisableCallback() {
    grp_node_->driverDisable();
}

void MainWindow::pushButton_cmdModbusOnCallback() {
    uint slave_address = 0;

    if (ui.radioButton_slave_address_1->isChecked()) {
        slave_address = 1;
    } else if (ui.radioButton_slave_address_2->isChecked()) {
        slave_address = 2;
    } else if (ui.radioButton_slave_address_3->isChecked()) {
        slave_address = 3;
    }

    if (slave_address != 0) {
        cout << "--------------------------------------" << endl;
        cout << "---[INFO] Slave address #" << slave_address << "------------" << endl;
        cout << "--------------------------------------" << endl;

        grp_node_->modbusInit(slave_address);
    } else {
        cout << "--------------------------------------" << endl;
        cout << "---[ERROR] Check the Slave address!---" << endl;
        cout << "--------------------------------------" << endl;
    }
}

void MainWindow::pushButton_cmdModbusOffCallback() {
    cout << "------------------------------" << endl;
    cout << "---[INFO] Modbus released !---" << endl;
    cout << "------------------------------" << endl;

    grp_node_->modbusRelease();
}

void MainWindow::pushButton_slaveChangeCallback() {
    uint slave_address = 0;

    if (ui.radioButton_slave_address_1->isChecked()) {
        slave_address = 1;
    } else if (ui.radioButton_slave_address_2->isChecked()) {
        slave_address = 2;
    } else if (ui.radioButton_slave_address_3->isChecked()) {
        slave_address = 3;
    }

    cout << "-----------------------------------" << endl;
    cout << "---[INFO] Slave changed to #" << to_string(slave_address) << "------" << endl;
    cout << "-----------------------------------" << endl;

    if (grp_node_->slaveChange(slave_address) != 0) {
        cout << "---[ERROR] Can not change slave address of mudbus_rtu !" << endl;
    }
}

void MainWindow::pushButton_cmdPowerOnCallback() {
    grp_node_->grpPowerCtrl(true);
}

void MainWindow::pushButton_cmdPowerOffCallback() {
    grp_node_->grpPowerCtrl(false);
}

void MainWindow::pushButton_cmdPosCtrlCallback() {
    PosCtrlParam pos_ctrl_param;

    pos_ctrl_param.pos      = ui.spinBox_pos_ctrl_position->value();
    pos_ctrl_param.vel      = ui.spinBox_pos_ctrl_velocity->value();
    pos_ctrl_param.duration = ui.spinBox_pos_ctrl_duration->value();

    grp_node_->posCtrl(pos_ctrl_param);
}

void MainWindow::pushButton_cmdVelCtrlCallback() {
    VelCtrlParam vel_ctrl_param;

    vel_ctrl_param.vel      = ui.spinBox_vel_ctrl_velocity->value();
    vel_ctrl_param.duration = ui.spinBox_vel_ctrl_duration->value();

    grp_node_->velCtrl(vel_ctrl_param);
}

void MainWindow::pushButton_cmdCurCtrlCallback() {
    CurCtrlParam cur_ctrl_param;

    cur_ctrl_param.cur      = ui.spinBox_cur_ctrl_current ->value();
    cur_ctrl_param.duration = ui.spinBox_cur_ctrl_duration->value();

    grp_node_->curCtrl(cur_ctrl_param);
}

void MainWindow::pushButton_setMaxValueCallback() {
    OtherParam other_param;

    other_param.vel_max = ui.spinBox_param_max_vel->value();
    other_param.acc_max = ui.spinBox_param_max_acc->value();

    grp_node_->setParam(other_param);
}

void MainWindow::pushButton_grpPosCtrlCallback() {
    uint16_t parameter;

    parameter = ui.spinBox_grpPos_ctrl_range->value();

    grp_node_->grpPosCtrl(parameter);
}

void MainWindow::pushButton_stopMotorCallback() {
    StopMotorParam stop_motor_param;

    stop_motor_param.duration = 100;

    grp_node_->stopMotor(stop_motor_param);
}

void MainWindow::pushButton_toggleCheckValueCallback() {
    grp_node_->toggleCheckValue();
}

void MainWindow::pushButton_grpInitCallback() {
    grp_node_->grpInit();
}

void MainWindow::pushButton_grpOpenCallback() {
    grp_node_->grpOpen();
}

void MainWindow::pushButton_grpCloseCallback() {
    grp_node_->grpClose();
}

void MainWindow::pushButton_setPIDCallback() {
    PIDParam PIDParameter;

    PIDParameter.P_Gain = ui.spinBox_param_P_Gain->value();
    PIDParameter.I_Gain = ui.spinBox_param_I_Gain->value();
    PIDParameter.D_Gain = ui.spinBox_param_D_Gain->value();

    grp_node_->setPIDGain(PIDParameter);
}

void MainWindow::pushButton_grpInit2Callback() {
    int16_t parameter = ui.spinBox_pos_ctrl_position_2->value();

    grp_node_->grpInit2(parameter);
}

void MainWindow::pushButton_vacOnCallback() {
    grp_node_->vacOn();
}

void MainWindow::pushButton_vacOffCallback() {
    grp_node_->vacOff();
}

}   // end of namespace