/**
 * @file /src/main.cpp
 *
 * @brief Qt based gui.
 *
 * @date November 2010
 **/
/*****************************************************************************
** Includes
*****************************************************************************/

#include <QtGui>
#include <QApplication>
#include "../include/main_window.hpp"

/*****************************************************************************
** Main
*****************************************************************************/

int main(int argc, char **argv) {

    /*********************
    ** Qt
    **********************/
    // if (argc < 3) {
    //     std::cout << "----------------------------" << std::endl;
    //     std::cout << "---[ERROR] Lack of argv !---" << std::endl;
    //     std::cout << "----------------------------" << std::endl;
    //     return -1;
    // }

    QApplication app(argc, argv);
    gripper_ui::MainWindow w(argc,argv);

    std::string ui_onoff_str = argv[2];

    if (ui_onoff_str == "ui_on") {
        std::cout << "------------------" << std::endl;
        std::cout << "---[INFO] UI on---" << std::endl;
        std::cout << "------------------" << std::endl;
        w.show();
    } else if (ui_onoff_str == "ui_off") {
        std::cout << "-------------------" << std::endl;
        std::cout << "---[INFO] UI off---" << std::endl;
        std::cout << "-------------------" << std::endl;
        w.hide();
    } else {
        std::cout << "--------------------------------------------------------------" << std::endl;
        std::cout << "---[ERROR] Wrong argv[2], please insert \"ui_on\" or \"ui_off\"---" << std::endl;
        std::cout << "--------------------------------------------------------------" << std::endl;
        return -1;
    }

    app.connect(&app, SIGNAL(lastWindowClosed()), &app, SLOT(quit()));
    int result = app.exec();

	return result;
}
