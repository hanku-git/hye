#ifndef TASK_DEFINE_HPP
#define TASK_DEFINE_HPP

#include <stdint.h>
#include <vector>
#include <string>

enum TASK_MODE {
    TASK_DEFAULT,
    TASK_DELAY,
    TASK_POS_CTRL,
    TASK_VEL_CTRL,
    TASK_CUR_CTRL,
    TASK_STOP_MOTOR,
    TASK_SET_PARAMETER
};

struct PosCtrlParam {
    int16_t pos;
    uint16_t vel;
    uint16_t duration;
};

struct VelCtrlParam {
    int16_t vel;
    uint16_t duration;
};

struct CurCtrlParam {
    int16_t cur;
    uint16_t duration;
};

struct StopMotorParam {
    uint16_t duration;
};

struct OtherParam {
    uint16_t vel_max;
    uint16_t acc_max;
};

struct PIDParam {
    int16_t P_Gain;
    int16_t I_Gain;
    int16_t D_Gain;
};

typedef struct _UnitTask {
    TASK_MODE task_mode;

    PosCtrlParam pos_ctrl_param;
    VelCtrlParam vel_ctrl_param;
    CurCtrlParam cur_ctrl_param;

    StopMotorParam stop_motor_param;

    OtherParam other_param;

    uint delay_ms;

    _UnitTask() {

    }
} UnitTask;

struct TaskParam {
	bool is_unit_task_fin = false;
    
	TASK_MODE task_mode = TASK_DEFAULT;

    uint task_num  = 0;
    uint time_ms   = 0;
	uint task_step = 0;	
};

struct sPacket {
    uint16_t data;
};

union Packet {
    sPacket data;
    int16_t p;
};

#endif // GRIPPER_TEST_H
